#! /usr/bin/python3

from prettytable import PrettyTable 


# Function uses the PterryTable Library to pump out our data into a nice table.
# Modularized it so save on lines of code. Plus I will use this function again for sure. 
def Pretty(List):
	# Var Dec: 
	Table = PrettyTable(["Task_ID", "Description", "Completed"]) # Create Header
		
	for x in List:
		# Check to See if Done! 
		if int(x[2]) == 1:
			Table.add_row([x[0], x[1], "(DONE!)"])
		else:
			Table.add_row([x[0], x[1], "(In Progress!)"])

	return Table


# Class used only in option history. A single function does the trick abbove but hey we like points. 
# I need to brush up more on gernerators and these __xxxx__ proporties before the exam. 
# Why do I need an array of objects when I can have an object return me arrays for output?
class Task:
	# Constructor 
	def __init__(self, DB_List): 
		self.__Completed_Array = DB_List

	def __str__(self):
		if len(self.__Completed_Array) == 0:
			return "[%] No Entries In DB..."

		else:
			return str(Pretty(self.__Completed_Array))

