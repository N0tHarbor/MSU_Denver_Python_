#! /usr/bin/python3

# Harbor Higginbotham
# CIS 3145-001
# Time 2 Hours-ish\
# Difficulty Easy/Medium 

import sys # Used to check if prettytable is and installed module
import subprocess # Used to check if prettytable is and installed module
import pkg_resources # Used to check if prettytable is and installed module
from business import *
from database import *

def main():

	# Var Dec:
	Loop = True
	Data_Obj = DB_To_Do()

	# Header
	print("="*70)
	print("\t\t\t  [&] Task List [&]")
	print("="*70)

	# Start UI:
	while(Loop):

		#Command List:
		print("""
COMMAND MENU
view		- View pending Tasks
history 	- View completed tasks
add 		- Add a task
complete 	- Complete a task
delete 		- Delete completed tasks
exit 		- Exit program""")

		# User Input:
		User_Input = str(input("\n[%] Command: "))
		
		# Interaction Back End: Lots of If Statmens. 
		if User_Input == "view":
			print(Pretty(Data_Obj.View()))
			

		elif User_Input == "history":
			print(Task(Data_Obj.History()))
			

		elif User_Input == "add":
			Data_Obj.Add(Data_Obj.Size(), Data_Obj.Sanitize(str(input("[$] Description: "))))
			print("[#] Data Added to DB")
			

		elif User_Input == "complete":
			Data_Obj.Complete(int(input("[*] Number: "))) # OOO immma test this injection later!!!!
			print("[@] Data Added to DB")
			

		elif User_Input == "delete":
			Data_Obj.Delete()
			print("[^] All completed tasks removed from the DB")
			

		elif User_Input == "exit":
			print("[!] Bye")
			exit(0)
		else:
			print(f"[^] User input invalid - {User_Input}")

if __name__ == '__main__':

	# Var Dec
	Reqs = {"prettytable"}
	Installed_Mods = {pkg.key for pkg in pkg_resources.working_set} 
	Missing = Reqs - Installed_Mods # ooooo Fuck a linear search!

	if Missing: # Whoa very pythonic 
		try:
			Uin = str(input(f"[&] Missing Packages {Missing}\n[&] Would you like to install? [y/n] "))
		except ValueError as Err:
			print(f"[&] Input Failed - Invalid Option: {User_Input} \n[&] Error: {Err}")
		else:
			if Uin == "y" or Uin == "Y":
				subprocess.check_call(["python3", '-m', 'pip', 'install', *Missing], stdout=subprocess.DEVNULL)
				print(f"[&] {Missing} Installed... Re-feed interpreter")
			else:
				print("Manualy run 'python3 -m pip install prettytable'")
				print("yOu CaNt DoC pOiNtS If I gAvE aN OpTiOn?\nidk man the project needed some spice sorry")
	main()


