#! /usr/bin/python3 

import sqlite3 
from contextlib import closing

class DB_To_Do:

	# Default Constructor:
	def __init__(self):
		self.__Conn = sqlite3.connect("./task_list_db.sqlite") # Connect to database

	# Sanatizes Input: Using it for later!
	def Sanitize(self, Input): # I mean works as far as I now lol.
		return Input.replace("'", "''").replace("#", "").replace("-", "")
		# Im gonna find a way to inject this.
		# Likly a time based injection.... IDK.. 

	# Query DB to get full list size to maintain entry order. 
	def Size(self):
		with closing(self.__Conn.cursor()) as ection:
			# Query:
			ection.execute("SELECT * FROM Task")

			# Return List:
			return len(ection.fetchall())

	# Views uncompleted tasks in the database. (IE: 0)
	def View(self):
		with closing(self.__Conn.cursor()) as ection:
			# Query:
			ection.execute("SELECT * FROM Task WHERE completed = 0")

			# Return List:
			return ection.fetchall()

	# Views Only Completed taks in the Databse. (IE: 1)
	def History(self):
		with closing(self.__Conn.cursor()) as ection:
			# Query:
			ection.execute("SELECT * FROM Task WHERE completed = 1")

			# Return List:
			return ection.fetchall()

	# Adds an item to the the to do list. 
	def Add(self, Id, Desc): # ID param must be obj.Size() to keep order consistant. 
		with closing(self.__Conn.cursor()) as ection:
			# Query:
			ection.execute(f'''INSERT INTO Task (taskID, description, completed) VALUES ({Id+1}, '{Desc}', 0)''')

			# Finalize Change:
			self.__Conn.commit()
		
	# Changes the completed column given an ID. 
	def Complete(self, Id):
		with closing(self.__Conn.cursor()) as ection:
			# Query:
			ection.execute(f'''UPDATE Task set completed = 1 WHERE taskID = {Id}''')

			# Finalize Change:
			self.__Conn.commit()
		
		
	# Deletes all entreis from the table "Tasks" where the item is completed. 
	def Delete(self):
		with closing(self.__Conn.cursor()) as ection:
			# Query:
			ection.execute(f'''DELETE FROM Task WHERE completed = 1''')

			# Finalize Change:
			self.__Conn.commit()




