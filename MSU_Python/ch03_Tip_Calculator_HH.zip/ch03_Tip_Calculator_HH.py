#! /usr/bin/python3
'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
[%] Harbor Higginbotham
[%] CIS 3150-001
[%] Chapter 3: Tip Calculator 
[%] Total Time: 20 min
[%] Dificulty: Very Easy 

'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

def main():

	# Header:
	print("="*35)
	print("[%] Tip Calculator [%]")
	print("="*35)

	# Input Validation: 
	try:
		# Get Uin:
		Cost = float(input("Enter the cost of the meal: "))

	except ValueError as err: 
		print("="*35)
		print(f"Input Invalid Due To : {err}")
		return 0

	else:
		# Var Calc:
		Tip = {Cost * .15, Cost * .20, Cost * .25}
		Count = 10

		for x in Tip:
			# Print Output:
			print("="*35)
			print(f"Tip Percentage %: {Count+5}")
			print(f"Tip Amount: {x}")
			print("Total: ", format((Cost+x), ".2f"))
			print("="*35)

if __name__ == '__main__':
	main()