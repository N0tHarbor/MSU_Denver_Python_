#! /usr/bin/python3

# Harbor Higginbotham
# CIS 3145-001
# Dificulty: Easy
# Time: 30 Min

import datetime as dt

def Arival(Date_And_Time, Distance, Speed):

	# Split Date_And_Time String:
	Parts = Date_And_Time.split()
	Depart_Date = Parts[0]
	Depart_Time = Parts[1] + " " + Parts[2]

	# Calculate Time of Flight:
	Added_Hours = int(Distance / Speed)
	Added_Miutes = int(((Distance / Speed) % 1) * 60)

	# Declare Date Time Object for Base Travel:

	Datetime_Obj = dt.datetime.strptime(Depart_Date + " " + Depart_Time, "%Y-%m-%d %I:%M %p")

    # Declare Date Time Object for time we want to add:
	Added_Time_Obj = dt.timedelta(hours=Added_Hours, minutes=Added_Miutes)

    # Add the travel time:
	New_Time = Datetime_Obj + Added_Time_Obj

	New_Time = New_Time.strftime("%Y-%m-%d %I:%M %p")

	# Print Findings:
	print("\nEstimated travel time")
	print(f"Hours: {Added_Hours}")
	print(f"Minutes: {Added_Miutes}")
	print(f"Estimated date of arrival:\n{New_Time}\n") # Format to desired output...

def main():

	# Variable Dec:
	Loop = True

	# Title:
	print("Arrival Time Estimator")

	# UI Loop:
	while(Loop):

		# User Input:
		DateOfDeparture = str(input("Enter date of departure (YYYY-MM-DD): "))
		TimeOfDeparture = str(input("Enter time of departure (HH:MM AM/PM): "))
		Travel_Dist = int(input("Enter miles: "))
		Mph = int(input("Enter miles per hour: "))

		# Function Call:
		Arival((DateOfDeparture + " " + TimeOfDeparture), Travel_Dist, Mph)

		# Loop Check:
		try:
			Check = str(input("Continue? (y/n):"))

		except ValueError as err:
			print(f"Error - {err}") # None String

		else:
			if Check == "n" or Check == "N":
				Loop = False
				print("\nBye!")


if __name__ == '__main__':
	main()