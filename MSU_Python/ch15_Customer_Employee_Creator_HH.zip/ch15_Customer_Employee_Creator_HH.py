#! /usr/bin/python3

# Harbor Higginbotham
# CIS 3145
# Dificulty Easy 
# Time 20 min

from company_objects import *

def main():
	# Variable Dec:
	Loop = True

	# Headr Print
	print("Customer/Employee Data Entry\n")

	# UI Loop:
	while(Loop):

		User_Input = str(input("Customer or employee? (c/e): "))

		# Cutstome Is Chossen: 
		if User_Input == "c":
			print("\nData Entry") # User Input Header

			# User Input
			Obj = Customer(input("First Name:\t"), input("Last Name:\t"), input("Email:\t"), input("Number:\t"))

			# Print Statement:
			print("\nCustomer")
			print(f"Name: {Obj.Full_Name()}")
			print(f"Email: {Obj.Get_Email()}")
			print(f"Number: {Obj.Get_ID()}")

		# Employee Is Chossen: 
		elif User_Input == "e":
			print("\nData Entry") # User Input Header

			# User Input
			Obj = Employee(input("First Name:\t"), input("Last Name:\t"), input("Email:\t"), input("SSN:\t"))

			# Print Statement:
			print("\nEmployee")
			print(f"Name: {Obj.Full_Name()}")
			print(f"Email: {Obj.Get_Email()}")
			print(f"SSN: {Obj.Get_ID()}")

		else:
			print(f"\nInvalid Input {User_Input}")


		# Loop Check
		Loop_Check = str(input("\nContinue? (y/n): "))

		if Loop_Check == "n":
			print("Bye!")
			Loop = False

		elif Loop_Check != "y":
			print(f"Invalid Input {Loop_Check}")
			print("Bye!")
			Loop = False

if __name__ == '__main__':
	main()