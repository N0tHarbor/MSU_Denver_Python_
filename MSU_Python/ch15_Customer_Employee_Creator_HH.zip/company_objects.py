#! /usr/bin/python3

class Person:
	# Default Constructor:
	def __init__(self, First, Last, Email):
		# Private varible Dec:
		self.__First = First
		self.__Last = Last
		self.__Email = Email

	# Full Name Method:
	def Full_Name(self):
		return str(self.__First + " " + self.__Last)

	# Get Email Method:
	def Get_Email(self):
		return str(self.__Email)


class Customer(Person):
	# Default Constructor:
	def __init__(self, First, Last, Email, Cust_ID):
		Person.__init__(self, First, Last, Email) # Inerit Class Person

		# Private varible Dec:
		self.__ID = Cust_ID

	# Get ID Method
	def Get_ID(self):
		return str(self.__ID)

class Employee(Customer):
	# Default Constructor:
	def __init__(self, First, Last, Email, Cust_ID): # Cust_ID is used for SSN in this class.
		Customer.__init__(self, First, Last, Email, Cust_ID) # Inherit Class Customer. 
		