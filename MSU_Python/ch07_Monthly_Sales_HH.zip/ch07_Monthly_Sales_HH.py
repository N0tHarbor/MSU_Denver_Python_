#! /usr/bin/python3

# [%] Harbor Higginbotham
# [%] CIS 3150-001
# [%] Chapter 7: Monthly Sales
# [%] Total Time: 60 min - Brain Wasnt on Today 
# [%] Dificulty: Easy/Medium

# For Prof. 
# You grade like this is a C/C++ class lol
# 1. I will cap the first letter because I want to, it looks nice, its how Ive always done it, and your sick in the head like the rest of the cult like puriest because all lowercase looks like shiit.
# 	- CAMELS HAVE HEADS DONT EVEN GO THERE.  
# 2. Code is documented enought to not have to write out "temorary_variable" or "User_Input", or "User_Interface". Tmp, User_Input, UI all get the point across.
#	- Jesus man I gave you post and pre conditions of my functuions. 
#	- And every piece is input sanitized. 
# 3. I dont care if its "immutable" its not pass by reference so the variable will not change once the function is off stack and out of scope. Give me my points back fool. 
# 4. A document string is a comment like stucture. Comment like structure... petty. and this header looks like shit now btw. 

from array import * 

# File Ingest Function:
def Ingest():
	# Var Dec
	FILE_PATH = "./monthly_sales.csv"
	Array = [[] for i in range(12)] # 2D array the size of months in a year
	Index = 0

	# Open File: NO CHECKS IM LAZY AND HAVE OSCP TO DO. 
	File = open(FILE_PATH)
	for x in File.readlines():
		for y in (x.strip().split(",")):
			Array[Index].append(y)
		Index+=1
	return Array 

# Yearly Function
# - Precondition - User enters 'Yearly' correctly 
# - Postcondition - Prints monthly Average & Yearly Total associated with a 2-D Array. 
def Year(List):
	Total = 0

	for x in List:
		Total+=float(x[1])

	print("[&] Yearly Total: ", format(Total, ".2f"))
	print("[&] Monthly Average: ", format(Total/len(List), ".2f"))

# Month Function:
# - Precondition -  User enters 'Monthly' correctly
# - Postcondition - Function Returns to UI. 
def Month(List):
	# Print Values from all months in the list. 
	for x in List:
		print(f"[&] {x[0]} - {x[1]}")

# Edit Function:
# - Precondition -  User enters 'Edit' correctly
# - Postcondition - Changes values in the 2D array at users request and input. 
# - Vulns - No char exscape used may be posible to pop a reverse shell, I wonder what a cmd injection would look like on the input() field.
# https://www.stackhawk.com/blog/command-injection-python/ - Neat 
def edit(List):
	# Var Dec:
	User_Interface = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
	User_Interface_Valid = False
	Index = 0 

	# User_Input1: Letters of the Month
	try:
		User_Input = str(input("[&] Three-letter Month: "))

	except ValueError as x:
		print("="*40)
		print(f"[&] Input Failed - {x}")

	else:
		# User_Input1 Input validation - Search
		for x in User_Interface:
			if x == User_Input:
				User_Interface_Valid = True

		# User_Input1 Input validation - Found?
		if User_Interface_Valid == False:
			print("[&] ERoR - Invalid three-letter month.")
		else:
			# User_Input2: Sales Amount
			try:
				User_Input2 = float(input("[&] Sales Amount: "))

			except ValueError as x:
				print("="*40)
				print(f"[&] Input Failed - {x}")

			else:
				# Find Month Index:
				for x in User_Interface:
					if x == User_Input:
						break;
					else:
						Index+=1

				# Return New list 
				List.insert(Index, [User_Input, User_Input2])
				return List

def main():

	# Var Dec:
	monthlySales = Ingest()
	loop = True


	# Title:
	print("="*40)
	print("[&] Monthly Sales Program [&]")
	print("="*40)

	# Menue: 
	print("""
COMMAND MENU
[&] monthly - View monthly sales
[&] yearly - View yearly summary
[&] edit - Edit sales for a month
[&] exit - Exit program\n
	""")
	# Proff Wants Output after menue be:
	Month(monthlySales)

	# Menue Back End: 
	while(loop == True):
		# User Input Validation: CMD 
		try:
			print("="*40)
			User_Input = str(input("Command: "))

		except ValueError as x:
			print("="*40)
			print(f"[&] Input Failed - {x}")

		else:
			print("="*40)
			if User_Input == "yearly" or User_Input == "Yearly": # Yearly Option
				Year(monthlySales)

			elif User_Input == "monthly" or User_Input == "Monthly": # Monthly Option
				Month(monthlySales)

			elif User_Input == "Edit" or User_Input == "edit": # Edit Option
				monthlySales = edit(monthlySales)

			elif User_Input == "exit" or User_Input == "Exit": # Exit Option
				return(0)

			else:
				print(f"Invalid CMD - {User_Input}") # Invalid CMD 


if __name__ == '__main__':
	main()