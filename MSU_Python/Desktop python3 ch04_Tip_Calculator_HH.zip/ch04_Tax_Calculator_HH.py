#! /usr/bin/python3
'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
[%] Harbor Higginbotham
[%] CIS 3150-001
[%] Chapter 4: Tax Calculator 
[%] Total Time: 20 min
[%] Dificulty: Easy 

'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
from CalculationsModule import * 

def main():

	# Header:
	print("="*35)
	print("[%] Sales Tax Calculator [%]")
	print("="*35)

	# Var Dec:
	Loop = True
	Uin = 0
	Count = 0 

	print("ENTER ITEMS (ENTER -99 TO END)")

	# Loop Start
	while(Loop == True):


		# Test User Input:
		try: 
			Uin = float(input("Cost of item: "))
			if int(Uin) != -99:
				Count += Uin

		except ValueError as err:
			print("="*35)
			print(f"[%] Invalid Input - {err}")
			print("="*35)
			return 0

		else:
			# Print Final Totals:
			if int(Uin) == -99:
				print("="*35)
				print("Total: ", format(Count, ".2f"))
				print("Sales tax: ", format(SalesT(Count), ".2f"))
				print("Total after tax: ", Total(Count, SalesT(Count)))

				# Loop Check:
				try: # User Input Validation 
					print("="*35)
					Tmp = str(input("Again? [y/n]: "))
					print("="*35)

				except ValueError as err:
					print("="*35)
					print(f"[%] Invalid Input - {err}")
					print("="*35)
					return 0

				else:
					if(Tmp == "y" or Tmp == "Y"):
						print("ENTER ITEMS (ENTER -99 TO END)")
						Uin = 0
						Count = 0
						
					else:
						print("Thanks, Bye!")
						Loop = False	

if __name__ == '__main__':
	main()