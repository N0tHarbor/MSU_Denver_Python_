#! /usr/bin/python3

def SalesT(Var): # Fucntion That Calcs what 6% of a int would be. Was of a MB's
	return Var * .06

def Total(V1, V2): # Function that adds two numbers together. Very useless, Not a good asignment to need a function for... 
	return float(V1 + V2)