#! /usr/bin/python3
'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
[%] Harbor Higginbotham
[%] CIS 3150-001
[%] Chapter 6: Monthly Sales
[%] Total Time: 60 min - Brain Wasnt on Today 
[%] Dificulty: Easy/Medium
'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
from array import * 

# Yearly Function
# - Precondition - User enters 'Yearly' correctly 
# - Postcondition - Prints monthly Average & Yearly Total associated with a 2-D Array. 
def Year(List):
	Total = 0

	for x in List:
		Total+=float(x[1])

	print("[&] Yearly Total: ", format(Total, ".2f"))
	print("[&] Monthly Average: ", format(Total/len(List), ".2f"))

# Month Function:
# - Precondition -  User enters 'Monthly' correctly
# - Postcondition -
def Month(List):
	# Print Values from all months in the list. 
	for x in List:
		print(f"[&] {x[0]} - {x[1]}")

# Edit Function:
# - Precondition -  User enters 'Edit' correctly
# - Postcondition - Changes values in the 2D array at users request and input. 
# - Vulns - No char exscape used may be posible to pop a reverse shell, I wonder what a cmd injection would look like on the input() field.
# https://www.stackhawk.com/blog/command-injection-python/ - Neat 
def edit(List):
	# Var Dec:
	UI = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
	UI_Valid = False
	Index = 0 

	# Uin1: Letters of the Month
	try:
		Uin = str(input("[&] Three-letter Month: "))

	except ValueError as x:
		print("="*40)
		print(f"[&] Input Failed - {x}")

	else:
		# Uin1 Input validation - Search
		for x in UI:
			if x == Uin:
				UI_Valid = True

		# Uin1 Input validation - Found?
		if UI_Valid == False:
			print("[&] ERoR - Invalid three-letter month.")
		else:
			# Uin2: Sales Amount
			try:
				Uin2 = float(input("[&] Sales Amount: "))

			except ValueError as x:
				print("="*40)
				print(f"[&] Input Failed - {x}")

			else:
				# Find Month Index:
				for x in UI:
					if x == Uin:
						break;
					else:
						Index+=1

				# Return New list 
				List.insert(Index, [Uin, Uin2])
				return List

def main():

	# Var Dec:
	monthlySales = [['Jan', '616'], ['Feb', '466'], ['Mar', '796'], ['Apr', '238'], ['May', '310'], ['Jun', '726'], ['Jul', '987'], ['Aug', '604'], ['Sep', '951'], ['Oct', '958'], ['Nov', '238'], ['Dec', '610']]
	loop = True


	# Title:
	print("="*40)
	print("[&] Monthly Sales Program [&]")
	print("="*40)

	# Menue: 
	print("""
COMMAND MENU
[&] monthly - View monthly sales
[&] yearly - View yearly summary
[&] edit - Edit sales for a month
[&] exit - Exit program\n
	""")
	# Menue Back End: 
	while(loop == True):
		# User Input Validation: CMD 
		try:
			print("="*40)
			Uin = str(input("Command: "))

		except ValueError as x:
			print("="*40)
			print(f"[&] Input Failed - {x}")

		else:
			print("="*40)
			if Uin == "yearly" or Uin == "Yearly": # Yearly Option
				Year(monthlySales)

			elif Uin == "monthly" or Uin == "Monthly": # Monthly Option
				Month(monthlySales)

			elif Uin == "Edit" or Uin == "edit": # Edit Option
				monthlySales = edit(monthlySales)

			elif Uin == "exit" or Uin == "Exit": # Exit Option
				return(0)

			else:
				print(f"Invalid CMD - {Uin}") # Invalid CMD 


if __name__ == '__main__':
	main()