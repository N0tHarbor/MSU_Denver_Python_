#! /usr/bin/python3

# Harbor Higginbotham 
# Time: 1 hr or so
# Dificulty: Easy 

import csv
from Customer_Class import *

def Read_CSV():
	# Var Dec:
	PATH = "./Cust_Data.csv" # So Sorry if you are a WIN man. 
	List = []

	# Open File
	with open(PATH, "r") as File:
		Temp = csv.DictReader(File) # Read as Dict to skip dealing with headers

		# Iterate each row 
		for x in list(Temp):
			# Append Obj to list:
			List.append(Customer(x["ID"], x["First"], x["Last"], x["Company"], x["Address"], x["City"], x["State"], x["Zip"]))

		# Return List of Objects to Main Variable Obj_List. 
		return List

def main():

	# Variable Dec:
	Loop = True
	Obj_List = Read_CSV() # Read CSV File to a list of object Varaibles

	print("[$] Cutomer Viewer [$]\n") # Header

	while(Loop):
		# User Interface: (UI)
		print("[$] Enter the customer ID to view the customer address\n")

		# Print Private Instance Variable 'ID':
		print("[$] Customer ID's in Database [$]")
		for x in Obj_List:
			print(x._Customer__Id) 
			# IDK why python lets you fucking mess with private vars like this. But, its nice shorthand. Eliminates the need for accessor and mutators. 
			# I do really love C++ classes more because I am biase and leared C++ first but damn is that nice syntatic sugar. 
			# Makes me wanna grind algos in C++ again but eh. 
			# I havent used any sorts too big for 0[n] and my i5. 
			# Well not since I was a CS major anyway... 
			# Would be nice too know more tho. 
			# Most of my work is in KQL, Bash and PS now... Love the dirty ghetoness of bash fr. 
			# When I am out of college I am gonna teach my self modern assembly so I can catch that rev eng patch drop wave!

			# What are your thoughts on this method of private instance var access?
			# ^ With great power....?

		# User Input - Customer ID:
		try:
			User_Input = str(input("\n[$] Enter Customer ID: "))

		except ValueError as Err:
			print(f"[$] Invalid Input {User_Input}\n[$] Error - {Err} ")

		else:
			# Check Uin For Valid ID:
			for x in Obj_List:
				if User_Input == x._Customer__Id:
					# Valid, Drop Shiping Info:
					x.Full_Addy()
					break # Break o(n) search. 
				# If last item:
				elif x._Customer__Id == Obj_List[len(Obj_List)-1]._Customer__Id:
					print("\n[$]No customer with that user ID...")

			# User Input - Continue Loop:
			try:
				Cont = str(input("\n[$] Continue? [y/n]"))

			except ValueError as Err:
				print(f"[$] Invalid Input {User_Input}\n[$] Error - {Err} ")

			else:
				if Cont != "y":
					print("Bye!")
					exit()

if __name__ == '__main__':
	main()

