#! /usr/bin/python3


class Customer():

	# Constructor:
	def __init__(self, Id, First, Last, Company, Addy, City, State, Zip): 
		# Private Variable Dec
		self.__Id = Id
		self.__First = First
		self.__Last = Last
		self.__Addy = Addy
		self.__City = City
		self.__State = State
		self.__Zip = Zip
		self.__Company = Company
		self.__Param = 8


	# Method - Full Address Print. 
	def Full_Addy(self):
		# Param Check: 
		if self.__Company == "":
			# Multi line print:
			print(f"""
{self.__First} {self.__Last} 
{self.__Addy} 
{self.__City}, {self.__State}, {self.__Zip}""") 
		else:
			# Multi line print:
			print(f"""
{self.__First} {self.__Last} 
{self.__Company}  
{self.__Addy} 
{self.__City}, {self.__State}, {self.__Zip}""") 