#! /usr/bin/python3


import csv 


def Read_List():
	# Variable Dec:
	NAME = "./player.csv"

	# Open File: 
	with open(NAME, "r") as File:
		Temp = csv.DictReader(File)

		Player_List = list(Temp)

		return Player_List



def Write_List(Data):
	# Variable Dec:
	NAME = "./player.csv"
	Columns = ['name', 'position', 'at_bats', 'hits']

	# Open File: 
	with open(NAME, "w") as File:
		Writing = csv.DictWriter(File, fieldnames=Columns)
		Writing.writeheader()
		for x in Data:
			Writing.writerow(x)
